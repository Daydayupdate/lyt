<?php
/**
 * WordPress基础配置文件。
 *
 * 这个文件被安装程序用于自动生成wp-config.php配置文件，
 * 您可以不使用网站，您需要手动复制这个文件，
 * 并重命名为“wp-config.php”，然后填入相关信息。
 *
 * 本文件包含以下配置选项：
 *
 * * MySQL设置
 * * 密钥
 * * 数据库表名前缀
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/zh-cn:%E7%BC%96%E8%BE%91_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL 设置 - 具体信息来自您正在使用的主机 ** //
/** WordPress数据库的名称 */
define( 'DB_NAME', 'sb' );

/** MySQL数据库用户名 */
define( 'DB_USER', 'sb' );

/** MySQL数据库密码 */
define( 'DB_PASSWORD', 'Lyt20202020' );

/** MySQL主机 */
define( 'DB_HOST', 'localhost' );

/** 创建数据表时默认的文字编码 */
define( 'DB_CHARSET', 'utf8mb4' );

/** 数据库整理类型。如不确定请勿更改 */
define( 'DB_COLLATE', '' );

/**#@+
 * 身份认证密钥与盐。
 *
 * 修改为任意独一无二的字串！
 * 或者直接访问{@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org密钥生成服务}
 * 任何修改都会导致所有cookies失效，所有用户将必须重新登录。
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ':]}YybiV/VJgvi-5usc<N@:Y#V|#F{sZ1?Ji*V0$Lac:WB9@hgMv1I 9R;M(%Huq' );
define( 'SECURE_AUTH_KEY',  'A[?lr:M6#vi(hKn1iXQVO<tuPFnx!~S !uor(e!u=+{h6<Qh-0ui]*>O!@II&o+`' );
define( 'LOGGED_IN_KEY',    'SX [_$avEy.iP%6.a&;lo>[q[ph`T=yXp-Rm7V #a_Qn&/LT3D%_*{Y4p,4KE+%0' );
define( 'NONCE_KEY',        '_aYjSYnCnpkT`a&LY3E5?T>jNE/(pI)Yq]}Ic&)T4rzwCi1HJHe)*;<z_^hC8P#F' );
define( 'AUTH_SALT',        'km8/5z*7h)$I9hZDZN1f>!tw)4tIutn/@LXZOrO}FY+!0cNhxYD($_O@$]$m9D2O' );
define( 'SECURE_AUTH_SALT', 'sDD3v]azIgr?#VVVs@6Cb}g9Pq7Ty-}iI|mlxh9R{9[zs71>DJ8|@,7DkW[;qx1+' );
define( 'LOGGED_IN_SALT',   '&SVwM|>_Ht@)I+EwA;35!$LD,(b[72DtQ;S:1.H2_Znn%bNA@2KG,rE-,5|b!, P' );
define( 'NONCE_SALT',       'fD@cdro%k`92lqW MnnmA0-~U%6)c3VR323G[Zp?6%fE.m.vlQ~,qCqn`)i1eJ/7' );

/**#@-*/

/**
 * WordPress数据表前缀。
 *
 * 如果您有在同一数据库内安装多个WordPress的需求，请为每个WordPress设置
 * 不同的数据表前缀。前缀名只能为数字、字母加下划线。
 */
$table_prefix = 'wp_';

/**
 * 开发者专用：WordPress调试模式。
 *
 * 将这个值改为true，WordPress将显示所有用于开发的提示。
 * 强烈建议插件开发者在开发环境中启用WP_DEBUG。
 *
 * 要获取其他能用于调试的信息，请访问Codex。
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* 好了！请不要再继续编辑。请保存本文件。使用愉快！ */

/** WordPress目录的绝对路径。 */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** 设置WordPress变量和包含文件。 */
require_once( ABSPATH . 'wp-settings.php' );
